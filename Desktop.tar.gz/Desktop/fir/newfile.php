<?php 
echo 'this is your first php page';


$array=array(33, 12, 67, 78, 20, 19, 1);
echo "<pre>"; print_r($array); echo "</pre>";



//for($i=0; $i<count($array);$i++)
//{
//	if($array[i]>($array[i+1]))
  //  {
    //    $temp_var = $array[$i];
    //	$array[$i]= $array[$i+1];
      //  $aray[$i+1] = $temp_var;
    //}
//}
//echo "<pre>"; print_r($array); echo "</pre>";
?>