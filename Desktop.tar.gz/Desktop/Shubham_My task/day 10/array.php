<?php 
echo 'this is your first php page';
$i;
$j;
$array=array(33, 12, 67, 78, 20, 19, 1);
echo "<pre>"; print_r($array); echo "</pre>";



for(i=0; i<count($array);i++)
{
	for(j=1;j<count($array)-1;j++)
	{
	if($array[j]>($array[j+1]))
    {
        $temp_var = $array[j+1];
    	$array[j+1]= $array[j];
        $array[j] = $temp_var;
    
    }

  }
}

echo "<pre>"; print_r($array); echo "</pre>"
?>