﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class exam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    Int32 c = 0;
    Int32 w = 0;
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=HP\SQLEXPRESS;Initial Catalog=exam;Integrated Security=True";
        conn.Open();
        string qry = "Select Answer from answer where Question='1'"; 
        SqlCommand com = new SqlCommand(qry, conn);
        SqlDataReader d;
        string one = rb1.SelectedValue;
        d = com.ExecuteReader();

        if (d.Read())
           
        {
            if (d[0].ToString() == one)
            {
                c = c + 1;

            }
            else
            {
                w++;
            }
        }
        conn.Close();
        conn.Open();
        string qry1 = "Select Answer from answer where Question='2'";
        SqlCommand com1 = new SqlCommand(qry1, conn);
        SqlDataReader d1;
        string two = rb2.SelectedValue;
        d1 = com1.ExecuteReader();

        if (d1.Read())
        {
            if (d1[0].ToString() == two)
            {
                c = c + 1;

            }
            else
            {
                w++;
            }
        }
        conn.Close();
        conn.Open();
        string qry2 = "Select Answer from answer where Question='3'";
        SqlCommand com2 = new SqlCommand(qry2, conn);
        SqlDataReader d2;
        string three = rb3.SelectedValue;
        d2 = com2.ExecuteReader();

        if (d2.Read())
        {
            if (d2[0].ToString() == three)
            {
                c = c + 1;

            }
            else
            {
                w++;
            }
        }



        Label1.Text = "No. of correct Answers  "+c;
        Label2.Text = "No. of Incorrect Answers " + w;
        HyperLink1.Text = "Click Here to go to HomePage";

        conn.Close();
    }
}