﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("registration.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        

        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"Data Source=HP\SQLEXPRESS;Initial Catalog=exam;Integrated Security=True";
        conn.Open();
        string qry = "Select Password from login where UserName='" + TextBox1.Text + "'";
        SqlCommand com = new SqlCommand(qry, conn);
        SqlDataReader d;
        d=com.ExecuteReader();
        if(d.Read()){
            if(d[0].ToString()==TextBox2.Text)
            {
                Response.Redirect("exam.aspx");
            }
            else
            {
                Label1.Text = "Invalid UserName or Password";
            }
        }
        else
        {
            Label1.Text = "Invalid UserName or Password";
        }
       
        
        
        conn.Close();
    }
}