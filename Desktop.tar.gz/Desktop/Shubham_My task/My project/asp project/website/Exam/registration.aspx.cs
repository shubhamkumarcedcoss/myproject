﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString =@"Data Source=HP\SQLEXPRESS;Initial Catalog=exam;Integrated Security=True";
        conn.Open();
        string qry = "Insert into login values ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')";
        SqlCommand com = new SqlCommand(qry, conn);
        com.ExecuteNonQuery();
        Label1.Text = "Registration Successful";
        HyperLink1.Text = "Click Here to login";
        conn.Close();
    }
}